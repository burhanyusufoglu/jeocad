using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

[assembly: AssemblyTitle("BURHAN YUSUFOĞLU - JeoCAD")]
[assembly: AssemblyDescription("Jeolojik Kesit ve Sondaj Kolon Tasarım Programı")]
[assembly: AssemblyCompany("BURHAN YUSUFOĞLU MÜHENDİSLİK")]
[assembly: AssemblyProduct("JeoCAD Geotechnical CAD Studio")]
[assembly: AssemblyCopyright("Copyright © 2026 Burhan Yusufoğlu")]
[assembly: AssemblyTrademark("JeoCAD")]
[assembly: AssemblyVersion("3.0.0.0")]
[assembly: AssemblyFileVersion("3.0.0.0")]

namespace BurhanYusufoglu.JeoCAD
{
    static class Program
    {
        [DllImport("shell32.dll", SetLastError = true)]
        private static extern void SetCurrentProcessExplicitAppUserModelID([MarshalAs(UnmanagedType.LPWStr)] string AppID);

        [STAThread]
        static void Main(string[] args)
        {
            try
            {
                SetCurrentProcessExplicitAppUserModelID("BurhanYusufoglu.JeoCAD.Studio.3.0");
            }
            catch { }

            string baseDir = AppDomain.CurrentDomain.BaseDirectory;
            string htmlPath = Path.Combine(baseDir, "index.html");

            if (!File.Exists(htmlPath))
            {
                string fixedDir = @"C:\Users\BURHAN\.gemini\antigravity\scratch\geosection_studio";
                if (File.Exists(Path.Combine(fixedDir, "index.html")))
                {
                    baseDir = fixedDir;
                    htmlPath = Path.Combine(baseDir, "index.html");
                }
            }

            // Donanım Kilitli Lisanslama için Windows Makine Kimliğini tespit et
            string machineGuid = "";
            try
            {
                using (var rk = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Cryptography"))
                {
                    if (rk != null)
                    {
                        var val = rk.GetValue("MachineGuid");
                        if (val != null) machineGuid = val.ToString();
                    }
                }
            }
            catch { }
            if (string.IsNullOrEmpty(machineGuid)) machineGuid = Environment.MachineName;

            try
            {
                string envJs = Path.Combine(baseDir, "license_env.js");
                File.WriteAllText(envJs, string.Format("window.JEOCAD_NATIVE_HWID = '{0}';", machineGuid));
            }
            catch { }

            if (!File.Exists(htmlPath))
            {
                MessageBox.Show("JeoCAD program dosyaları (index.html) bulunamadı:\n" + htmlPath,
                                "JeoCAD - Başlatma Hatası",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                return;
            }

            string profileDir = Path.Combine(baseDir, "AppData", "JeoCAD_Profile");
            try
            {
                if (!Directory.Exists(profileDir))
                {
                    Directory.CreateDirectory(profileDir);
                }
            }
            catch { }

            string[] possibleBrowsers = new string[]
            {
                @"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
                @"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
                @"C:\Program Files\Google\Chrome\Application\chrome.exe",
                @"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), @"Microsoft\Edge\Application\msedge.exe"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), @"Google\Chrome\Application\chrome.exe")
            };

            string browserExe = null;
            foreach (string p in possibleBrowsers)
            {
                if (File.Exists(p))
                {
                    browserExe = p;
                    break;
                }
            }

            if (browserExe == null)
            {
                MessageBox.Show("Microsoft Edge veya Google Chrome tarayıcısı bulunamadı.",
                                "JeoCAD", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string fileUri = new Uri(htmlPath).AbsoluteUri;
            ProcessStartInfo psi = new ProcessStartInfo();
            psi.FileName = browserExe;
            psi.Arguments = string.Format(
                "--app=\"{0}\" --start-maximized --user-data-dir=\"{1}\" --allow-file-access-from-files --no-first-run --no-default-browser-check --disable-features=Translate,OptimizationHints,msEdgeSidebarV2 --disable-extensions",
                fileUri,
                profileDir
            );
            psi.UseShellExecute = false;

            try
            {
                Process.Start(psi);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message, "JeoCAD", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
